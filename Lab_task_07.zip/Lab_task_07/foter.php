<!DOCTYPE html>
<html>
<head>
      <title>footer</title>
<link rel="stylesheet" type="text/css" href="foter.css" />
</head>
<body>



<div class="footer">
  <a href="about us.php"> About us </a> <label > | </label>
  <a href="policy.php"> Privacy Policy</a> <label > | </label>
  <a href="Contractus.php"> Contract us </a> 

  <p>Copyright © 2021 </p>

</div>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
<title>DASHBOARD</title>
<style>




</style>
</head>
<body>


<section>
  <nav>
  

  <p> </p>
    <ul>
     
      <li><a href="a.php">Electronic handheld Devices </a></li>
      <li><a href="b.php">Electronic Accessories</a></li>
      <li><a href="c.php">TV & accessories</a></li>
      <li><a href="d.php">AC & accessories</a></li>
       <li><a href="e.php">Computer & accessories</a></li>
      <li><a href="f.php">Refrigerator</a></li>
      <li><a href="g.php">Washing Machine</a></li>
   









      <li><a href="session_cookie\destroySession.php">Logout</a></li>

    </ul>
  </nav>
  




</body>
</html>

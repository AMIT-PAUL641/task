<!DOCTYPE html>
<html>
<head>
<style> 
.search {
  width: 100%;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
   
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  
}


</style>
</head>
<body>

<p>Animated search input:</p>


<div> 
  
  <input class="search" type="text" name="search" placeholder="Search..">

</div>

</body>
</html>

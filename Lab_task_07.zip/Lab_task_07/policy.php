
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css.css" /></head>
<body>

<body>


  <?php include 'head.php' ?>  



<div class="row">
  <div class="col-3 col-s-3 menu">
   
  
  </div>

<h2>Helping Hand service</h1>
<h3>Privacy Policy</h3>

<?php
echo " 

This privacy policy has been compiled to better serve those who are concerned with how their ‘Personally identifiable information’ (PII) is being used online. PII, as used in US privacy law and information security, is information that can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context. Please read our privacy policy carefully to get a clear understanding of how we collect, use, protect or otherwise handle your Personally Identifiable Information in accordance with our website.

What personal information do we collect from the people that visit our website or blog?

When ordering or registering on our site, as appropriate, you may be asked to enter your name, email address, mailing address, phone number or other details to help you with your experience.

When do we collect information?

We collect information from you when you subscribe to a newsletter, respond to a survey, fill out a form or enter information on our site.

How do we use your information?

We may use the information we collect from you when you register, make a purchase, sign up for our newsletter, respond to a survey or marketing communication, surf the website, or use certain other site features in the following ways:

• To personalize user’s experience and to allow us to deliver the type of content and product offerings in which you are most interested.
• To improve our website in order to better serve you.
• To administer a contest, promotion, survey or other site feature."

?> 

  </div>
 <br>
<a href="css design.php"> Back </a>
  <br>
  
</div>

<div class="footer">
  <p><?php include 'foter.php' ?></p>
</div>

</body>
</html>





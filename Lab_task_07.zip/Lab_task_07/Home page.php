<!DOCTYPE html>
<html>
<head>
  <title>PUblic Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" type="text/css" href="css.css" />

</head>
<body>


 <?php include 'head.php' ?>  



<div class="row">
  <div class="col-3 col-s-3 menu">
    <ul> 
      <li><?php include 'account.php' ?></li> 
    </ul>

    
    <!-- <ul>
      <li>The Flight</li>
      <li>The City</li>
      <li>The Island</li>
      <li>The Food</li>
    </ul> -->
  </div>

  <div class="col-9 col-s-12">
    <h1>Welcome </h1>
    <p> Here you can buy Home Appliance devices. If your devices/product had some problem or broken then you can take our Servicing for reparing thoes</p>
  <p> If your devices/product had some problem or broken then you can take our Servicing for reparing thoes.  </p>  

  </div>

  
</div>

<div class="footer">
  <p><?php include 'foter.php' ?></p>
</div>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css.css" /></head>
<body>

<body>

 <?php include 'head.php' ?> 

</div>

<div class="row">
  <div class="col-3 col-s-3 menu">
   
  
  </div>
<h3>Contract Us</h3>

<?php
echo "

It has been founded on 27 june -2020.
 From then to now, Helping Hand service has won the heart of many people and now is a country-wide renowned brand."
?> 
<h3>The Main Goal and Aim</h3>
<?php
echo "
We are Helping Hand service, and we are here to help you with all your technology needs. We aim to provide all the requirements of our customers and help them satisfy their needs, wants, and desires. We delight in seeing our customers happy and satisfied with our resiliency in providing them with their products. Our complete focus is on the customers.";
?>


  </div>
  <br>
<a href="css design.php"> Back </a>
  <br>


</div>

<div class="footer">
  <p><?php include 'foter.php' ?></p>
</div>

</body>
</html>



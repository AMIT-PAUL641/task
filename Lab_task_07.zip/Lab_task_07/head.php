<!DOCTYPE html>
<html>
<head>
	<title>Header</title>
<link rel="stylesheet" type="text/css" href="head.css" />
</head>
<body>

<div class="">
<div class="header">

  <div class="h1">
     <span style="color:black ; font-weight:bold">Home Appliance and Servicing</span>
   </div>
   
<div class="searchbox">
     
    <input class="search" type="text" name="search" placeholder="Search ">
  </div>


<div class="h2">
	
  <a href="PublicHome.php" >Home </a>
  <label >&nbsp&nbsp</label>

  <a href="Login.php" >Account</a>
  <label >&nbsp&nbsp</label>

  <a href="addUser.php" >Registration</a>

 </div>
  </div>
</div>



</body>
</html>